import "./modal.js";
import "./modalinputs.js";